<?php
/** @var string $content 已渲染并转义的主体 HTML */
/** @var string $title @var string $siteTitle @var string $shell site|admin */
use PenBlog\Theme\View;
$themeToggle = static fn (): string => '<button class="theme-toggle" type="button" aria-label="切换深色/浅色模式" aria-pressed="false">'
    . '<svg class="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"/></svg>'
    . '<svg class="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>'
    . '</button>';
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= View::e($title ?? $siteTitle ?? 'PenBlog') ?></title>
<script>try{var t=localStorage.getItem('pb-theme');if(t==='dark'||t==='light')document.documentElement.dataset.theme=t;}catch(e){}</script>
<link rel="stylesheet" href="/assets/paper.css">
<?= $tokensCss ?? '' ?>
</head>
<body class="<?= View::e($bodyClass ?? '') ?>">
<a class="skip-link" href="#main">跳到主内容</a>
<?php if (($shell ?? 'site') === 'admin'): ?>
<div class="admin-shell">
  <aside class="admin-sidebar" aria-label="后台导航">
    <a href="/admin/dashboard" <?= ($page ?? '') === 'dashboard' ? 'aria-current="page"' : '' ?>>内容</a>
    <a href="/admin/posts/new">写文章</a>
    <a href="/admin/notifications" <?= ($page ?? '') === 'notifications' ? 'aria-current="page"' : '' ?>>通知</a>
    <a href="/admin/notifications/preferences">通知偏好</a>
    <a href="/admin/plugins" <?= ($page ?? '') === 'plugins' ? 'aria-current="page"' : '' ?>>插件</a>
    <a href="/admin/themes" <?= ($page ?? '') === 'themes' ? 'aria-current="page"' : '' ?>>主题</a>
    <a href="/admin/menus" <?= ($page ?? '') === 'menus' ? 'aria-current="page"' : '' ?>>菜单</a>
    <a href="/admin/xp" <?= ($page ?? '') === 'xp' ? 'aria-current="page"' : '' ?>>经验</a>
    <?php foreach (($pluginMenu ?? []) as $pm): ?>
      <a href="<?= View::e($pm['item']->url) ?>"><?= View::e($pm['item']->label) ?></a>
    <?php endforeach; ?>
    <a href="/" target="_blank" rel="noopener">查看站点</a>
  </aside>
  <div class="admin-main">
    <header class="admin-topbar">
      <strong>PenBlog 后台</strong>
      <?= $themeToggle() ?>
      <div class="menu bell-menu" data-menu>
        <button class="menu-btn bell-btn" type="button" aria-haspopup="true" aria-expanded="false" aria-label="通知<?= !empty($bellUnread) ? '(' . (int) $bellUnread . ' 条未读)' : '' ?>">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8a6 6 0 1 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>
          <?php if (!empty($bellUnread)): ?><span class="bell-badge"><?= (int) min(99, (int) $bellUnread) ?></span><?php endif; ?>
        </button>
        <div class="menu-panel bell-panel" role="menu" aria-label="最近通知">
          <?php if (empty($bellItems)): ?>
            <p class="bell-empty">暂无通知</p>
          <?php else: foreach ($bellItems as $b): ?>
            <a role="menuitem" class="bell-item<?= $b['read_at'] === null ? ' unread' : '' ?>"
               href="<?= View::e(($b['link'] ?? '') !== '' ? (string) $b['link'] : '/admin/notifications') ?>"
               data-notif-read="<?= (int) $b['id'] ?>">
              <span class="notif-dot" aria-hidden="true"></span>
              <span class="bell-item-title"><?= View::e($b['title'] !== '' ? (string) $b['title'] : '(通知)') ?></span>
              <time><?= View::e(\PenBlog\Theme\View::ago((string) $b['created_at'])) ?></time>
            </a>
          <?php endforeach; endif; ?>
          <div class="bell-foot">
            <a href="/admin/notifications">查看全部</a>
            <?php if (!empty($bellUnread)): ?>
            <form method="post" action="/admin/notifications/read-all">
              <input type="hidden" name="_csrf" value="<?= View::e($csrf ?? '') ?>">
              <button type="submit">全部已读</button>
            </form>
            <?php endif; ?>
          </div>
        </div>
      </div>
      <span class="meta" style="margin-inline-start:auto"><?= View::e($adminUser ?? '') ?> · <?= View::e($adminLevelTitle ?? '') ?></span>
      <form method="post" action="/admin/logout" style="display:inline">
        <input type="hidden" name="_csrf" value="<?= View::e($csrf ?? '') ?>">
        <button class="btn btn-secondary" type="submit">退出</button>
      </form>
    </header>
    <div class="admin-content" id="main"><?php if (!empty($updateInfo)): ?>
      <p class="badge badge-pending" role="status">检测到新版本 <?= View::e((string) $updateInfo['from']) ?> → <?= View::e((string) $updateInfo['to']) ?>:请在服务器运行 <code>php bin/migrate.php</code> 完成升级(自动备份,失败回滚)。</p>
    <?php endif; ?><?= $content ?></div>
  </div>
</div>
<?php else: ?>
<header class="site-header">
  <div class="container">
    <a class="site-logo" href="/"><?= View::e($siteTitle ?? 'PenBlog') ?></a>
    <nav class="nav-links" aria-label="主导航">
      <?php foreach (($primaryMenu ?? []) as $pm): ?>
        <a href="<?= View::e($pm['href']) ?>"<?= $pm['href'] === '/' && ($page ?? '') === 'home' ? ' aria-current="page"' : '' ?>><?= View::e($pm['label']) ?></a>
      <?php endforeach; ?>
      <?php foreach (($siteMenu ?? []) as $sm): ?>
        <a href="<?= View::e($sm['item']->url) ?>"><?= View::e($sm['item']->label) ?></a>
      <?php endforeach; ?>
      <?php if (!empty($authed)): ?>
        <a href="/admin/dashboard" <?= ($page ?? '') === 'dashboard' ? 'aria-current="page"' : '' ?>>后台</a>
      <?php endif; ?>
      <?= $themeToggle() ?>
    </nav>
  </div>
</header>
<main id="main" class="container"><?= $content ?></main>
<footer class="site-footer">
  <div class="container">
    <?php if (!empty($footerMenu)): ?>
      <nav class="footer-links" aria-label="页脚导航">
        <?php foreach ($footerMenu as $fm): ?>
          <a href="<?= View::e($fm['href']) ?>"><?= View::e($fm['label']) ?></a>
        <?php endforeach; ?>
      </nav>
    <?php endif; ?>
    <p>Powered by PenBlog · <?= View::e($siteTitle ?? '') ?><?= ($footerText ?? '') !== '' ? ' · ' . View::e((string) $footerText) : '' ?></p>
  </div>
</footer>
<?php endif; ?>
<script src="/assets/paper.js?v=20261031a" defer></script>
</body>
</html>
