<?php

return array (
  'penblog_version' => '0.9.0-m11',
  'app' => 
  array (
    'debug' => false,
    'url' => 'http://localhost:8080',
    'secret_key' => 'cfc3b37d3f23b42dc742b086378aa5d7e135b9d4787c9b53c92592864ad33b84',
  ),
  'db' => 
  array (
    'driver' => 'sqlite',
    'path' => '/workspace/penblog/storage/data.db',
  ),
  'paths' => 
  array (
    'logs' => '/workspace/penblog/storage/logs/app.log',
    'themes' => '/workspace/penblog/themes',
    'plugins' => '/workspace/penblog/plugins',
  ),
);
